# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['kalm',
 'kalm.airflow',
 'kalm.awx',
 'kalm.dns',
 'kalm.gitea',
 'kalm.inabox',
 'kalm.jenkins',
 'kalm.netbox',
 'kalm.pypi',
 'kalm.traefik']

package_data = \
{'': ['*']}

install_requires = \
['hvac>=1.1.0,<2.0.0',
 'mypy>=0.910,<0.911',
 'netbox>=0.0.2,<0.0.3',
 'pynetbox>=6.6.2,<7.0.0',
 'pytest>=6.2,<7.0',
 'python-jenkins>=1.7.0,<2.0.0',
 'redis>=4.5.3,<5.0.0',
 'requests>=2.25,<3.0',
 'urllib3>=2.0.2,<3.0.0']

entry_points = \
{'console_scripts': ['kalm = kalm:main',
                     'kalm_airflow = kalm.airflow:main',
                     'kalm_dns = kalm.dns:main',
                     'kalm_gitea = kalm.gitea:main',
                     'kalm_inabox = kalm.inabox:main',
                     'kalm_jenkins = kalm.jenkins:main',
                     'kalm_netbox = kalm.netbox:main',
                     'kalm_traefik = kalm.traefik:main']}

setup_kwargs = {
    'name': 'kalm',
    'version': '0.7.57',
    'description': 'Knowit Automation lifecycle management',
    'long_description': None,
    'author': 'Jakob Holst',
    'author_email': 'jakob.holst@knowit.dk',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://kalm.openknowit.com',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
