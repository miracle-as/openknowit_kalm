import requests
import json
import os
import base64
import xml.etree.ElementTree as ET

def list_gitea():
  print("list gitea")
  